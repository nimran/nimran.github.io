package com.imran.fluxsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.reactive.ReactiveUserDetailsServiceAutoConfiguration;
import org.springframework.web.reactive.config.EnableWebFlux;

@EnableWebFlux
@SpringBootApplication(exclude= {ReactiveUserDetailsServiceAutoConfiguration.class})
public class FluxsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(FluxsecurityApplication.class, args);
	}

}
