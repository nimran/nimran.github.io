package com.imran.fluxsecurity;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
import org.springframework.security.web.server.authorization.ServerAccessDeniedHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@Component
public class MyCustomAuthenticationEntryPoint implements ServerAuthenticationEntryPoint, ServerAccessDeniedHandler {

	@Override
	public Mono<Void> commence(ServerWebExchange exchange, AuthenticationException e) {
		  String result = String.format("{\"code\":\"%s\",\"message\": \"%s\"}", "401", e.getMessage());
	        ServerHttpResponse response = exchange.getResponse();
	        response.setStatusCode(HttpStatus.OK);
	        response.getHeaders().set(HttpHeaders.CONTENT_TYPE, "application/json");
	        return response.writeWith(Mono.just(response.bufferFactory().allocateBuffer().write(result.getBytes())));
	    }

	@Override
	public Mono<Void> handle(ServerWebExchange exchange, AccessDeniedException e) {
		String result = String.format("{\"code\":\"%s\",\"message\": \"%s\"}", "401", e.getMessage());
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.OK);
        response.getHeaders().set(HttpHeaders.CONTENT_TYPE, "application/json");
        return response.writeWith(Mono.just(response.bufferFactory().allocateBuffer().write(result.getBytes())));
   
	}

}
